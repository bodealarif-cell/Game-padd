# NEXUS Controller (Android)

Lightweight native Android Bluetooth HID gamepad prototype. The phone acts as a Bluetooth HID gamepad and the Android tablet is the Bluetooth host. The tablet normally does **not** need a companion app: pair it in Android Bluetooth settings and supported games can receive standard gamepad input.

## Important compatibility note

Android's `BluetoothHidDevice` support depends on the phone's Android build, Bluetooth stack, and vendor implementation. Some phones do not expose the HID Device profile to third-party apps. If NEXUS shows that the profile is unavailable, this build cannot work on that phone without a different approach. The tablet/game must support external Bluetooth gamepads. Touch-only games will not automatically become gamepad-compatible.

## Build

1. Open this folder in Android Studio (Hedgehog or newer).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Build > Build APK(s), then install the debug APK on the **phone/controller**.
4. Grant Bluetooth permissions. Tap **تفعيل Bluetooth / الاقتران**.
5. On the tablet, open Bluetooth settings and pair with **NEXUS Controller**. Keep the controller app open while playing.

Minimum Android API: 28. Target SDK: 35. No internet permission, analytics, ads, or third-party runtime libraries.

## Controls

- Gamepad mode: left stick emits X/Y, right stick emits Rx/Ry, face buttons and auxiliary buttons send a 16-bit button bitmap.
- Racing mode: steering uses X; throttle/brake and auxiliary controls are mapped to buttons for broad compatibility. This is a prototype mapping, not a universal racing-game profile.
- Release button resets all inputs.

## Known prototype limitations

- Virtual touch zones are basic and intended for a first hardware/compatibility test; layout and multitouch behavior should be refined after device testing.
- HID profile availability and pairing behavior vary by OEM. Bluetooth HID is classic Bluetooth HID, not BLE GATT; classic HID is the correct route for appearing as a standard gamepad to a host.
- Axis/button mapping differs between games. A calibration and remapping screen is a planned next step.
