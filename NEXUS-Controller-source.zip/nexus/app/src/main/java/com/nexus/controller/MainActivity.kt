package com.nexus.controller

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val cyan = Color.rgb(54, 217, 255)
    private val bg = Color.rgb(9, 13, 22)
    private val panel = Color.rgb(19, 27, 42)
    private val white = Color.rgb(239, 246, 255)
    private val muted = Color.rgb(139, 157, 181)
    private lateinit var status: TextView
    private lateinit var controller: ControllerSurface
    private var racing = false
    private var hid: BluetoothHidDevice? = null
    private var connectedHost: BluetoothDevice? = null
    private var registered = false
    private val adapter: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }
    private val mainHandler = Handler(Looper.getMainLooper())

    private val hidCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(device: BluetoothDevice?, plugged: Boolean) {
            registered = plugged
            mainHandler.post {
                status.text = if (plugged) "HID جاهز • اقترن من التابلت" else "Bluetooth HID غير مسجل"
                status.setTextColor(if (plugged) cyan else muted)
            }
        }
        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            mainHandler.post {
                when (state) {
                    BluetoothProfile.STATE_CONNECTED -> {
                        connectedHost = device
                        status.text = "متصل • ${safeName(device)}"
                        status.setTextColor(cyan)
                        controller.invalidate()
                    }
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        if (connectedHost?.address == device?.address) connectedHost = null
                        status.text = if (registered) "جاهز • افتح Bluetooth في التابلت" else "غير متصل"
                        status.setTextColor(muted)
                        sendReport()
                    }
                }
            }
        }
    }

    private val profileListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile != BluetoothProfile.HID_DEVICE) return
            hid = proxy as? BluetoothHidDevice
            registerHid()
        }
        override fun onServiceDisconnected(profile: Int) { hid = null; registered = false }
    }

    private fun safeName(device: BluetoothDevice?): String = try { device?.name ?: "Tablet" } catch (_: SecurityException) { "Tablet" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        requestBtPermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setBackgroundColor(bg)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "NEXUS  /  CONTROLLER"
            textSize = 18f; setTextColor(white); letterSpacing = .08f
        }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(42), 1f))
        status = TextView(this).apply { text = "Bluetooth غير متصل"; textSize = 12f; setTextColor(muted); gravity = Gravity.CENTER_VERTICAL }
        top.addView(status)
        root.addView(top)

        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(8)) }
        val gamepad = Button(this).apply { text = "GAMEPAD"; isAllCaps = false; setOnClickListener { racing = false; controller.setRacing(false); refreshMode(modes) } }
        val race = Button(this).apply { text = "RACING"; isAllCaps = false; setOnClickListener { racing = true; controller.setRacing(true); refreshMode(modes) } }
        modes.addView(gamepad, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        modes.addView(race, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
        root.addView(modes)

        controller = ControllerSurface(this) { buttons, x, y, rx, ry ->
            buttonMask = buttons
            axes = intArrayOf(x, y, rx, ry)
            sendReport()
        }
        root.addView(controller, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val pair = Button(this).apply { text = "تفعيل Bluetooth / الاقتران"; isAllCaps = false; setOnClickListener { enableAndPair() } }
        bottom.addView(pair, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(8) })
        val release = Button(this).apply { text = "تحرير"; isAllCaps = false; setOnClickListener { buttonMask = 0; axes = intArrayOf(0,0,0,0); sendReport(); controller.resetInput() } }
        bottom.addView(release, LinearLayout.LayoutParams(dp(90), dp(48)))
        root.addView(bottom)
        setContentView(root)
        refreshMode(modes)
    }

    private fun refreshMode(modes: LinearLayout) {
        for (i in 0 until modes.childCount) {
            val b = modes.getChildAt(i) as Button
            b.setBackgroundColor(if ((i == 1) == racing) Color.rgb(17, 87, 112) else panel)
            b.setTextColor(if ((i == 1) == racing) cyan else white)
        }
    }

    private var buttonMask = 0
    private var axes = intArrayOf(0, 0, 0, 0)

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            val needed = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_SCAN)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 42) else initBluetooth()
        } else initBluetooth()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) initBluetooth()
        else Toast.makeText(this, "يلزم السماح بصلاحيات Bluetooth لتشغيل ذراع التحكم", Toast.LENGTH_LONG).show()
    }

    private fun initBluetooth() {
        val a = adapter
        if (a == null) { status.text = "الجهاز لا يدعم Bluetooth"; return }
        try {
            if (!a.isEnabled) {
                startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 10)
                return
            }
            val ok = a.getProfileProxy(this, profileListener, BluetoothProfile.HID_DEVICE)
            if (!ok) status.text = "هذا الهاتف لا يتيح ملف Bluetooth HID Device"
        } catch (e: SecurityException) { status.text = "صلاحيات Bluetooth غير متاحة" }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) initBluetooth()
    }

    private fun registerHid() {
        val profile = hid ?: return
        try {
            val descriptor = byteArrayOf(
                0x05, 0x01,       // Usage Page (Generic Desktop)
                0x09, 0x05,       // Usage (Game Pad)
                0xA1.toByte(), 0x01, // Collection (Application)
                0x85.toByte(), 0x01, // Report ID 1
                0x05, 0x09,       // Usage Page (Button)
                0x19, 0x01, 0x29, 0x10, // Buttons 1..16
                0x15, 0x00, 0x25, 0x01, 0x95.toByte(), 0x10, 0x75, 0x01, 0x81.toByte(), 0x02,
                0x05, 0x01,       // Generic Desktop
                0x09, 0x30, 0x09, 0x31, 0x09, 0x33, 0x09, 0x34, // X Y Rx Ry
                0x15, 0x81.toByte(), 0x25, 0x7F, 0x75, 0x08, 0x95.toByte(), 0x04, 0x81.toByte(), 0x02,
                0xC0.toByte()
            )
            val sdp = BluetoothHidDeviceAppSdpSettings("NEXUS Controller", "Bluetooth gamepad", "NEXUS", BluetoothHidDevice.SUBCLASS1_GAMEPAD, descriptor)
            profile.registerApp(sdp, mainHandler::post, mainHandler::post, hidCallback)
        } catch (e: Exception) {
            status.text = "تعذر تفعيل HID: ${e.javaClass.simpleName}"
        }
    }

    private fun enableAndPair() {
        if (adapter == null) return
        if (hid == null) { initBluetooth(); return }
        try {
            val discoverable = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply { putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300) }
            startActivity(discoverable)
            status.text = if (registered) "ابحث عن NEXUS Controller من التابلت" else "جارٍ تجهيز Bluetooth HID..."
        } catch (e: Exception) { status.text = "تعذر بدء الاقتران" }
    }

    private fun sendReport() {
        val profile = hid ?: return
        val host = connectedHost ?: return
        try {
            val b = buttonMask.coerceIn(0, 0xFFFF)
            val payload = byteArrayOf((b and 0xFF).toByte(), ((b shr 8) and 0xFF).toByte(), axes[0].toByte(), axes[1].toByte(), axes[2].toByte(), axes[3].toByte())
            profile.sendReport(host, 1, payload)
        } catch (_: SecurityException) { }
        catch (_: Exception) { }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { hid?.unregisterApp() } catch (_: Exception) { }
        try { hid?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) } } catch (_: Exception) { }
        super.onDestroy()
    }

    private inner class ControllerSurface(context: Context, val changed: (Int, Int, Int, Int, Int) -> Unit) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var racingMode = false
        private var leftX = 0f; private var leftY = 0f; private var rightX = 0f; private var rightY = 0f
        private var leftPointer = -1; private var rightPointer = -1
        private val activeButtons = mutableSetOf<Int>()
        private var widthF = 0f; private var heightF = 0f
        fun setRacing(v: Boolean) { racingMode = v; resetInput(); invalidate() }
        fun resetInput() { leftX=0f; leftY=0f; rightX=0f; rightY=0f; leftPointer=-1; rightPointer=-1; activeButtons.clear(); updateState(); invalidate() }

        override fun onDraw(c: Canvas) {
            super.onDraw(c); widthF = width.toFloat(); heightF = height.toFloat()
            p.color = panel; p.style = Paint.Style.FILL
            c.drawRoundRect(RectF(0f,0f,widthF,heightF), dp(22).toFloat(), dp(22).toFloat(), p)
            p.color = Color.rgb(32,47,67); p.style = Paint.Style.STROKE; p.strokeWidth = dp(1).toFloat()
            c.drawRoundRect(RectF(dp(1).toFloat(),dp(1).toFloat(),widthF-dp(1),heightF-dp(1)), dp(22).toFloat(),dp(22).toFloat(),p); p.style=Paint.Style.FILL
            val cy = heightF * .57f
            if (!racingMode) {
                drawStick(c, widthF*.19f, cy, leftX,leftY,"MOVE")
                drawStick(c, widthF*.39f, cy, rightX,rightY,"LOOK")
                drawButton(c,widthF*.78f,cy-dp(34),dp(25).toFloat(),"Y",4)
                drawButton(c,widthF*.84f,cy,dp(25).toFloat(),"B",1)
                drawButton(c,widthF*.72f,cy,dp(25).toFloat(),"X",2)
                drawButton(c,widthF*.78f,cy+dp(34),dp(25).toFloat(),"A",0)
                drawSmall(c,widthF*.57f,heightF*.25f,"L1",6); drawSmall(c,widthF*.69f,heightF*.25f,"R1",7)
                drawSmall(c,widthF*.88f,heightF*.25f,"START",9); drawSmall(c,widthF*.12f,heightF*.25f,"SELECT",8)
                drawDpad(c,widthF*.55f,cy)
            } else {
                drawSteering(c,widthF*.25f,cy, leftX)
                drawPedal(c,widthF*.66f,heightF*.54f,"BRAKE",11)
                drawPedal(c,widthF*.82f,heightF*.54f,"THROTTLE",10)
                drawSmall(c,widthF*.12f,heightF*.22f,"GEAR -",12); drawSmall(c,widthF*.27f,heightF*.22f,"GEAR +",13)
                drawSmall(c,widthF*.88f,heightF*.22f,"NITRO",14)
            }
            p.color=muted; p.textSize=dp(10).toFloat(); p.textAlign=Paint.Align.CENTER
            c.drawText(if (racingMode) "RACING MODE • TOUCH & HOLD" else "GAMEPAD MODE • TOUCH & HOLD",widthF/2,heightF-dp(12).toFloat(),p)
        }

        private fun drawStick(c: Canvas,cx:Float,cy:Float,x:Float,y:Float,label:String) {
            p.color=Color.rgb(31,45,65); c.drawCircle(cx,cy,dp(54).toFloat(),p)
            p.color=Color.rgb(63,85,111); p.style=Paint.Style.STROKE; p.strokeWidth=dp(2).toFloat(); c.drawCircle(cx,cy,dp(54).toFloat(),p); p.style=Paint.Style.FILL
            p.color=cyan; c.drawCircle(cx+x*dp(32),cy+y*dp(32),dp(23).toFloat(),p)
            p.color=Color.WHITE; p.textSize=dp(9).toFloat(); p.textAlign=Paint.Align.CENTER; c.drawText(label,cx,cy+dp(76).toFloat(),p)
        }
        private fun drawButton(c:Canvas,cx:Float,cy:Float,r:Float,label:String,id:Int) {
            p.color=if(activeButtons.contains(id)) cyan else Color.rgb(37,53,75); c.drawCircle(cx,cy,r,p)
            p.color=if(activeButtons.contains(id)) bg else white; p.textSize=dp(15).toFloat(); p.textAlign=Paint.Align.CENTER; c.drawText(label,cx,cy+dp(5).toFloat(),p)
        }
        private fun drawSmall(c:Canvas,cx:Float,cy:Float,label:String,id:Int) {
            val r=RectF(cx-dp(29),cy-dp(15),cx+dp(29),cy+dp(15)); p.color=if(activeButtons.contains(id)) cyan else Color.rgb(35,50,70); c.drawRoundRect(r,dp(10).toFloat(),dp(10).toFloat(),p)
            p.color=if(activeButtons.contains(id)) bg else white; p.textSize=dp(9).toFloat(); p.textAlign=Paint.Align.CENTER; c.drawText(label,cx,cy+dp(3).toFloat(),p)
        }
        private fun drawDpad(c:Canvas,cx:Float,cy:Float) {
            p.color=Color.rgb(38,53,73); c.drawRoundRect(RectF(cx-dp(12),cy-dp(38),cx+dp(12),cy+dp(38)),dp(5).toFloat(),dp(5).toFloat(),p); c.drawRoundRect(RectF(cx-dp(38),cy-dp(12),cx+dp(38),cy+dp(12)),dp(5).toFloat(),dp(5).toFloat(),p)
            p.color=cyan; p.textSize=dp(10).toFloat(); p.textAlign=Paint.Align.CENTER; c.drawText("+",cx,cy+dp(4).toFloat(),p)
        }
        private fun drawSteering(c:Canvas,cx:Float,cy:Float,x:Float) {
            p.color=Color.rgb(37,53,75); p.style=Paint.Style.STROKE; p.strokeWidth=dp(13).toFloat(); c.drawCircle(cx,cy,dp(65).toFloat(),p); p.style=Paint.Style.FILL
            p.color=cyan; p.strokeWidth=dp(9).toFloat(); p.style=Paint.Style.STROKE; c.drawArc(RectF(cx-dp(65),cy-dp(65),cx+dp(65),cy+dp(65)),205f+x*90f,130f,false,p); p.style=Paint.Style.FILL
            p.color=Color.rgb(54,76,103); c.drawCircle(cx,cy,dp(24).toFloat(),p); p.color=white; p.textSize=dp(10).toFloat(); p.textAlign=Paint.Align.CENTER; c.drawText("STEER",cx,cy+dp(4).toFloat(),p)
        }
        private fun drawPedal(c:Canvas,cx:Float,cy:Float,label:String,id:Int) {
            val r=RectF(cx-dp(31),cy-dp(58),cx+dp(31),cy+dp(58)); p.color=if(activeButtons.contains(id)) cyan else Color.rgb(37,53,75); c.drawRoundRect(r,dp(13).toFloat(),dp(13).toFloat(),p)
            p.color=if(activeButtons.contains(id)) bg else white; p.textSize=dp(9).toFloat(); p.textAlign=Paint.Align.CENTER; c.drawText(label,cx,cy,p)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val actionIndex=e.actionIndex; val id=e.getPointerId(actionIndex); val x=e.getX(actionIndex); val y=e.getY(actionIndex)
            when(e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    if (x < widthF*.29f && leftPointer == -1) leftPointer=id else if (!racingMode && x >= widthF*.29f && x < widthF*.50f && rightPointer == -1) rightPointer=id else if (x < widthF*.29f && leftPointer != -1 && !racingMode && rightPointer == -1) rightPointer=id
                    buttonFor(x,y,true)
                }
                MotionEvent.ACTION_MOVE -> {
                    for(i in 0 until e.pointerCount) {
                        val pid=e.getPointerId(i); val px=e.getX(i); val py=e.getY(i)
                        if(pid==leftPointer) { leftX=(((px-widthF*.19f)/dp(55)).coerceIn(-1f,1f)); leftY=(((py-heightF*.57f)/dp(55)).coerceIn(-1f,1f)) }
                        if(pid==rightPointer) { rightX=(((px-widthF*.39f)/dp(55)).coerceIn(-1f,1f)); rightY=(((py-heightF*.57f)/dp(55)).coerceIn(-1f,1f)) }
                    }
                    invalidate(); updateState()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                    if(id==leftPointer) { leftPointer=-1; leftX=0f; leftY=0f }
                    if(id==rightPointer) { rightPointer=-1; rightX=0f; rightY=0f }
                    activeButtons.clear()
                    if(e.actionMasked!=MotionEvent.ACTION_CANCEL) buttonFor(x,y,false)
                    invalidate(); updateState()
                }
            }
            invalidate(); updateState(); return true
        }

        private fun buttonFor(x:Float,y:Float,down:Boolean) {
            if(!down) { activeButtons.clear(); return }
            val cy=heightF*.57f
            if(!racingMode) {
                val spots=listOf(Triple(widthF*.78f,cy+dp(34),0),Triple(widthF*.72f,cy,2),Triple(widthF*.84f,cy,1),Triple(widthF*.78f,cy-dp(34),4),Triple(widthF*.57f,heightF*.25f,6),Triple(widthF*.69f,heightF*.25f,7),Triple(widthF*.88f,heightF*.25f,9),Triple(widthF*.12f,heightF*.25f,8))
                spots.forEach { (bx,by,bid)-> if(kotlin.math.hypot((x-bx).toDouble(),(y-by).toDouble())<dp(36)) activeButtons.add(bid) }
                if(x>widthF*.5f && y>heightF*.35f && y<heightF*.75f && x<widthF*.64f) activeButtons.add(if(y<cy)5 else 3)
            } else {
                if(x>widthF*.59f && x<widthF*.73f) activeButtons.add(11)
                if(x>widthF*.75f && x<widthF*.9f) activeButtons.add(10)
                if(x>widthF*.82f && y<heightF*.35f) activeButtons.add(14)
                if(x<widthF*.2f && y<heightF*.35f) activeButtons.add(12)
                if(x>widthF*.2f && x<widthF*.36f && y<heightF*.35f) activeButtons.add(13)
            }
        }
        private fun updateState() {
            val x=(leftX*127).toInt(); val y=(leftY*127).toInt()
            val rx=(if(racingMode) leftX else rightX)*127
            val ry=(if(racingMode) 0f else rightY)*127
            var mask=0
            activeButtons.forEach { mask=mask or (1 shl it) }
            // Racing throttle/brake are represented as face buttons for broad game compatibility.
            changed(mask,x,y,rx.toInt(),ry.toInt())
        }
    }
}
